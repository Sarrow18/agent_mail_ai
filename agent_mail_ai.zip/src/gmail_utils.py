import os, base64
from googleapiclient.discovery import build
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow

SCOPES = ['https://www.googleapis.com/auth/gmail.modify']

def gmail_authenticate():
    creds = None
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        with open('token.json', 'w') as token:
            token.write(creds.to_json())
    return build('gmail', 'v1', credentials=creds)

def get_last_messages(service, max_results=5):
    results = service.users().messages().list(userId='me', maxResults=max_results, q="is:unread").execute()
    return results.get('messages', [])

def get_message_content(service, msg_id):
    msg = service.users().messages().get(userId='me', id=msg_id, format='full').execute()
    payload = msg['payload']
    headers = payload.get("headers", [])
    subject = next((h["value"] for h in headers if h["name"] == "Subject"), "(Sans objet)")
    body = ""

    if "parts" in payload:
        for part in payload["parts"]:
            if part["mimeType"] == "text/plain":
                body = base64.urlsafe_b64decode(part["body"]["data"]).decode("utf-8")
                break
    else:
        if "data" in payload["body"]:
            body = base64.urlsafe_b64decode(payload["body"]["data"]).decode("utf-8")

    return subject, body

def apply_label(service, msg_id, label_name):
    labels = service.users().labels().list(userId='me').execute()
    label_id = None
    for l in labels["labels"]:
        if l["name"].lower() == label_name.lower():
            label_id = l["id"]
            break

    if not label_id:
        new_label = {'name': label_name, 'labelListVisibility': 'labelShow', 'messageListVisibility': 'show'}
        created_label = service.users().labels().create(userId='me', body=new_label).execute()
        label_id = created_label["id"]

    service.users().messages().modify(
        userId='me',
        id=msg_id,
        body={"addLabelIds": [label_id], "removeLabelIds": []}
    ).execute()
