from gmail_utils import gmail_authenticate, get_last_messages, get_message_content, apply_label
from classifier import classify_email

def main():
    service = gmail_authenticate()
    messages = get_last_messages(service, max_results=3)

    if not messages:
        print("📭 Aucun nouveau mail.")
        return

    for m in messages:
        subject, body = get_message_content(service, m["id"])
        category = classify_email(subject, body)
        print(f"[+] Mail '{subject}' classé dans : {category}")
        apply_label(service, m["id"], category)

if __name__ == "__main__":
    main()
