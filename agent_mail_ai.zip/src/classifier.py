import openai

openai.api_key = "TA_CLE_OPENAI"

def classify_email(subject, body):
    prompt = f"""
    Tu es un assistant qui classe les emails.
    Sujet : {subject}
    Contenu : {body[:800]}

    Classe le mail dans une de ces catégories :
    - Factures
    - RH
    - Commercial
    - Autres

    Réponds uniquement par le nom de la catégorie.
    """
    response = openai.ChatCompletion.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}],
        temperature=0
    )
    return response["choices"][0]["message"]["content"].strip()
