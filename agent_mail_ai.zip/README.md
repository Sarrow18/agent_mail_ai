# 📧 Agent Mail AI

Un agent intelligent qui lit vos emails Gmail et les classe automatiquement dans des dossiers via Google Workspace en utilisant **ChatGPT**.

## 🚀 Installation

1. Clonez le repo :
```bash
git clone https://github.com/<ton-user>/agent_mail_ai.git
cd agent_mail_ai
```

2. Installez les dépendances :
```bash
pip install -r requirements.txt
```

3. Activez l’API Gmail :
- Allez sur [Google Cloud Console](https://console.cloud.google.com/).
- Créez un projet.
- Activez **Gmail API**.
- Créez un identifiant OAuth 2.0 de type "Application Bureau".
- Téléchargez le fichier `credentials.json` et placez-le dans la racine du projet.

## ▶️ Utilisation

Lancez le script principal :
```bash
python src/main.py
```

La première fois, une fenêtre de connexion Google s’ouvrira.  
Un fichier `token.json` sera créé pour conserver votre session.

## ⚡ Fonctionnement

- Récupère les mails non lus
- Envoie le contenu à ChatGPT pour classification (`Factures`, `RH`, `Commercial`, `Autres`)
- Applique automatiquement un label Gmail

## ⚠️ Sécurité

Ne poussez jamais vos fichiers `credentials.json` et `token.json` sur GitHub.  
Ils sont déjà listés dans `.gitignore`.

## 🛠️ Améliorations possibles
- Déploiement sur **Google Cloud Run** ou **cron job** pour exécution automatique
- Ajout de nouvelles catégories dynamiques
- Réponses automatiques aux emails selon la catégorie
